# ISC/BOMA — Site (Next.js)

Migration de ton site vitrine (index.html) vers Next.js, pour préparer la Phase 2
(authentification + espace étudiant).

## Démarrer en local

1. Installe [Node.js](https://nodejs.org) si ce n'est pas déjà fait (version 18 ou plus).
2. Dans ce dossier, installe les dépendances :
   ```
   npm install
   ```
3. Lance le serveur de développement :
   ```
   npm run dev
   ```
4. Ouvre [http://localhost:3000](http://localhost:3000) dans ton navigateur.

## ⚠️ À faire avant que le site soit complet : ajouter tes images

Le HTML que tu as modifié référence deux images qui n'étaient pas dans le fichier
que tu m'as envoyé (seul le code peut être transmis dans le chat, pas les fichiers
image liés). Dépose-les dans le dossier `public/` avec exactement ces noms :

- `public/isc-logo.png` → ton logo (utilisé dans le header et le footer)
- `public/about-poster.jpg` → la photo/affiche de la section "À propos"

Renomme simplement tes fichiers avant de les copier — j'ai choisi des noms propres
(sans espace ni parenthèse) parce que les noms de fichiers originaux avec espaces
et parenthèses posent parfois problème dans les URLs.

## Ce qui a changé par rapport à ton fichier HTML

- Le code est découpé en composants (`components/Header.js`, `Hero.js`, etc.) au lieu
  d'un seul fichier — plus facile à retrouver et modifier une section précise.
- Le menu mobile et le formulaire de contact utilisent maintenant `useState` (la façon
  React de gérer un changement d'état) au lieu de manipuler le HTML directement en JS.
- **Bug corrigé** : le lien email dans la section Contact n'avait pas `mailto:` devant
  l'adresse — le clic n'ouvrait rien. C'est réparé.
- Le CSS n'a pas changé : il est dans `app/globals.css`, copié tel quel.

## Prochaine étape : pousser sur GitHub

```
git add .
git commit -m "Migration du site vers Next.js"
git push
```

## Après ça : Phase 2

Une fois ce site en ligne et validé, on met en place Supabase (authentification +
base de données) pour construire la connexion étudiante et le tableau de bord.
