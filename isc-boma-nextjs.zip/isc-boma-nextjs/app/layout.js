import "./globals.css";

export const metadata = {
  title: "Institut Supérieur de Commerce de Boma (ISC/BOMA) — Inscriptions 2026-2027",
  description:
    "ISC/BOMA — Institut Supérieur de Commerce de Boma. Formations LMD en gestion, commerce, finance et informatique de gestion. Inscriptions 2026-2027.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <head>
        <meta name="theme-color" content="#2D8AE0" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&family=Inter:wght@400;500;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
