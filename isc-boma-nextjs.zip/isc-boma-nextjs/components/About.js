export default function About() {
  return (
    <section className="about" id="apropos">
      <div className="about-inner">
        <div className="about-visual" aria-hidden="true">
          {/* Remplace /about-poster.jpg dans le dossier public/ par ta propre image */}
          <img
            src="/about-poster.jpg"
            alt="Affiche de l’ISC/BOMA"
            style={{ maxWidth: "100%", height: "auto", borderRadius: 8 }}
          />
        </div>
        <div className="about-content">
          <span className="eyebrow">Qui sommes-nous</span>
          <h2>Une institution tournée vers le monde professionnel</h2>
          <p>
            L’Institut Supérieur de Commerce de Boma (ISC/BOMA) est un établissement
            d’enseignement supérieur dédié à la formation de cadres et de professionnels capables
            de répondre aux exigences du monde économique et professionnel contemporain.
          </p>
          <p>
            Implanté à Boma, dans la province du Kongo Central, l’ISC/BOMA propose des formations
            selon le système LMD (Licence-Master-Doctorat), avec des possibilités de cours de jour
            et du soir.
          </p>
          <p>
            À travers ses formations, l’ISC/BOMA ambitionne de contribuer à l’émergence de
            compétences capables d’intégrer le marché de l’emploi, de créer des entreprises et de
            participer activement au développement de leur communauté et de leur pays.
          </p>
        </div>
      </div>
    </section>
  );
}
