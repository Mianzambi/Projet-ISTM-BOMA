export default function Hero() {
  return (
    <>
      <section className="hero" id="accueil">
        <div className="hero-inner">
          <span className="pill-badge">
            <span className="dot"></span> Inscriptions 2026–2027 ouvertes
          </span>
          <h1>Bienvenue à l’INSTITUT SUPERIEUR DE COMMERCE DE BOMA</h1>
          <p className="hero-sub">
            L’ISC/BOMA leader en science commercial, elle forme, selon le système LMD, les cadres
            et professionnels capables de répondre aux exigences du monde économique contemporain.
          </p>
          <div className="hero-actions">
            <a href="#contact" className="btn btn-primary">S’inscrire maintenant</a>
            <a href="#apropos" className="btn btn-outline-light">En savoir plus</a>
          </div>
        </div>
        <div className="stat-strip">
          <div className="stat">
            <span className="stat-num">8+</span>
            <span className="stat-label">Filières de Licence</span>
          </div>
          <div className="stat">
            <span className="stat-num">2026</span>
            <span className="stat-label">Année académique</span>
          </div>
          <div className="stat">
            <span className="stat-num">Jour & Soir</span>
            <span className="stat-label">Régime des cours</span>
          </div>
        </div>
      </section>
      <div className="hero-spacer"></div>
    </>
  );
}
