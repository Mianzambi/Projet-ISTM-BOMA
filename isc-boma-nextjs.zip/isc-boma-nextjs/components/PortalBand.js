export default function PortalBand() {
  return (
    <div className="wrap">
      <div className="portal-band" id="espace">
        <div className="portal-inner">
          <div>
            <h2>Votre espace personnel</h2>
            <p>
              Un espace pour gérer votre inscription, consulter vos résultats et suivre votre
              parcours académique, accessible en ligne.
            </p>
            <div className="portal-features">
              <div className="portal-feature">
                <span className="check">✓</span> Suivi de votre dossier d’inscription
              </div>
              <div className="portal-feature">
                <span className="check">✓</span> Consultation des résultats et relevés
              </div>
              <div className="portal-feature">
                <span className="check">✓</span> Connexion sécurisée, 24h/24
              </div>
            </div>
            <p className="portal-note">
              Cet espace est en cours de construction — en attendant, contacte-nous directement
              ci-dessous.
            </p>
          </div>
          <div style={{ textAlign: "center" }}>
            <a href="#contact" className="btn btn-outline-light">Nous contacter</a>
          </div>
        </div>
      </div>
    </div>
  );
}
