export default function Values() {
  return (
    <section className="values">
      <div className="values-inner">
        <div className="section-head" style={{ marginBottom: 0 }}>
          <span className="eyebrow">Nos valeurs</span>
          <h2>Excellence, efficience, émergence</h2>
          <p>
            Les trois valeurs qui guident chaque formation dispensée à l’ISC/BOMA, avec une
            ambition claire : former aujourd’hui les leaders de demain.
          </p>
        </div>
        <div className="values-grid">
          <div className="value-card">
            <div className="value-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#2D8AE0" strokeWidth="1.6">
                <path d="M12 2l2.9 6.3 6.9.6-5.2 4.6 1.6 6.8L12 16.9l-6.2 3.4 1.6-6.8L2.2 8.9l6.9-.6z" />
              </svg>
            </div>
            <h3>Excellence</h3>
            <p>Un enseignement exigeant, aligné sur les standards académiques du système LMD.</p>
            <div className="value-tags">
              <span className="tag">Rigueur</span>
              <span className="tag">Qualité</span>
            </div>
          </div>

          <div className="value-card">
            <div className="value-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#2D8AE0" strokeWidth="1.6">
                <path d="M13 2L3 14h7l-1 8 10-12h-7z" />
              </svg>
            </div>
            <h3>Efficience</h3>
            <p>Des parcours pensés pour préparer directement à l’insertion professionnelle.</p>
            <div className="value-tags">
              <span className="tag">Pratique</span>
              <span className="tag">Terrain</span>
            </div>
          </div>

          <div className="value-card">
            <div className="value-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#2D8AE0" strokeWidth="1.6">
                <path d="M3 17l6-6 4 4 8-8M21 7v6M21 7h-6" />
              </svg>
            </div>
            <h3>Émergence</h3>
            <p>Contribuer au développement économique de Boma, du Kongo Central et du pays.</p>
            <div className="value-tags">
              <span className="tag">Impact</span>
              <span className="tag">Avenir</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
