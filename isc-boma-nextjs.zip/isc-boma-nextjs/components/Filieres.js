const licence = [
  "Comptabilité et Gestion Financière",
  "Marketing",
  "Fiscalité, Douane et Accises",
  "Banque, Microfinance et Assurance",
  "Gestion des Ressources Humaines",
  "Entrepreneuriat et Gestion des Entreprises",
  "Logistique et Transport",
  "Informatique de Gestion",
];

const master = [
  "Comptabilité, Contrôle et Audit",
  "Marketing",
  "Fiscalité, Douanes, Accises et Commerce International",
  "Entrepreneuriat, Gestion et Évaluation des Projets",
  "Informatique de Gestion — Administration Réseaux",
  "Informatique de Gestion — Architecture Logicielle",
];

export default function Filieres() {
  return (
    <section className="filieres" id="filieres">
      <div className="section-head">
        <span className="eyebrow">Nos formations</span>
        <h2>Des parcours en prise avec le monde économique</h2>
        <p>
          Des formations en Licence et en Master, construites autour des besoins du secteur privé
          et public.
        </p>
      </div>

      <div className="filiere-group">
        <h3>Premier cycle — Licence</h3>
        <div className="filiere-pills">
          {licence.map((item) => (
            <span className="filiere-pill" key={item}>
              {item}
            </span>
          ))}
        </div>
      </div>

      <div className="filiere-group">
        <h3>Deuxième cycle — Master</h3>
        <div className="filiere-pills">
          {master.map((item) => (
            <span className="filiere-pill" key={item}>
              {item}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
