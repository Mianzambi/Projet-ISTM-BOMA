export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-inner">
        <div>
          <div className="footer-brand">
            {/* Remplace /isc-logo.png dans le dossier public/ par ton propre fichier */}
            <img
              src="/isc-logo.png"
              alt="Logo ISC BOMA"
              style={{ height: 40, width: "auto", marginRight: 10 }}
            />
            ISC / BOMA
          </div>
          <p>
            Institut Supérieur de Commerce de Boma — établissement d’enseignement supérieur,
            Boma, Kongo Central, République Démocratique du Congo.
          </p>
        </div>
        <div className="footer-col">
          <h4>Navigation</h4>
          <ul>
            <li><a href="#accueil">Accueil</a></li>
            <li><a href="#apropos">À propos</a></li>
            <li><a href="#filieres">Filières</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </div>
        <div className="footer-col">
          <h4>Contact</h4>
          <ul>
            <li>Boma, Kongo Central, RDC</li>
            <li>+243 89 120 2814 / 83 859 7773</li>
            <li>iscboma2024@gmail.com</li>
          </ul>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© 2026 ISC/BOMA. Tous droits réservés.</span>
        <span>Site conçu par Fils Mianzambi</span>
      </div>
    </footer>
  );
}
