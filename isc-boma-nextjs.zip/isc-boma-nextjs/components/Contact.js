"use client";

import { useState } from "react";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    // Démo sans backend : à relier à un vrai service d'emailing (ex. Resend, Formspree)
    // ou à ton propre backend en Phase 2/3.
    setSubmitted(true);
    e.target.reset();
  }

  return (
    <section className="contact" id="contact">
      <div className="contact-inner">
        <div className="contact-info">
          <span className="eyebrow">Nous contacter</span>
          <h2>Restons en contact</h2>
          <ul>
            <li>
              <span className="contact-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2D8AE0" strokeWidth="1.8">
                  <path d="M21 10c0 7-9 12-9 12S3 17 3 10a9 9 0 1118 0z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
              </span>
              <div>
                <strong>Adresse</strong>
                <span>Route Ficher, en face de l’Hôtel La Candide Boma, Kongo Central, RDC</span>
              </div>
            </li>
            <li>
              <span className="contact-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2D8AE0" strokeWidth="1.8">
                  <path d="M22 16.9v3a2 2 0 01-2.2 2 19.8 19.8 0 01-8.6-3 19.5 19.5 0 01-6-6 19.8 19.8 0 01-3-8.7A2 2 0 014.1 2h3a2 2 0 012 1.7c.1 1 .3 2 .7 3a2 2 0 01-.5 2.1L8 10a16 16 0 006 6l1.3-1.3a2 2 0 012.1-.4c1 .3 2 .5 3 .6a2 2 0 011.6 2z" />
                </svg>
              </span>
              <div>
                <strong>Téléphone</strong>
                <a href="https://wa.me/243891202814" target="_blank" rel="noopener noreferrer" style={{ textDecoration: "underline" }}>
                  +243 89 120 2814
                </a>{" / "}
                <a href="https://wa.me/243838597773" target="_blank" rel="noopener noreferrer" style={{ textDecoration: "underline" }}>
                  +243 83 859 7773
                </a>
              </div>
            </li>
            <li>
              <span className="contact-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2D8AE0" strokeWidth="1.8">
                  <path d="M4 4h16v16H4z" />
                  <path d="M4 4l8 9 8-9" />
                </svg>
              </span>
              <div>
                <strong>Email</strong>
                {/* Corrigé : il manquait "mailto:" dans le lien d'origine, le clic n'ouvrait rien */}
                <a href="mailto:iscboma2024@gmail.com">iscboma2024@gmail.com</a>
              </div>
            </li>
          </ul>
        </div>

        <div className="contact-form-card">
          <form className="contact-form" onSubmit={handleSubmit}>
            <div className="form-row">
              <label>
                Nom complet
                <input type="text" name="name" required />
              </label>
              <label>
                Email
                <input type="email" name="email" required />
              </label>
            </div>
            <label>
              Sujet
              <input type="text" name="subject" />
            </label>
            <label>
              Message
              <textarea name="message" required></textarea>
            </label>
            <button type="submit" className="btn btn-primary">Envoyer</button>
            {submitted && (
              <p className="form-note">
                Message enregistré localement pour la démo. Pour un envoi réel, ce formulaire
                devra être relié à un service d’emailing (Phase 3).
              </p>
            )}
          </form>
        </div>
      </div>
    </section>
  );
}
