"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { licence, passerelle, master, niveauxParCycle } from "@/lib/filieres";
import { DOCUMENTS } from "@/lib/documents";
import { statutLabels } from "@/lib/statuts";

const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5 Mo
const ACCEPTED_TYPES = ["application/pdf", "image/jpeg", "image/png"];

export default function InscriptionFormPage() {
  const router = useRouter();
  const [supabase] = useState(() => createClient());

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [statut, setStatut] = useState(null);

  const [cycle, setCycle] = useState("Licence");
  const [filiere, setFiliere] = useState("");
  const [niveau, setNiveau] = useState("");
  const [vacation, setVacation] = useState("");
  const [dateNaissance, setDateNaissance] = useState("");
  const [lieuNaissance, setLieuNaissance] = useState("");
  const [sexe, setSexe] = useState("");
  const [adresse, setAdresse] = useState("");
  const [telephone, setTelephone] = useState("");
  const [ecoleOrigine, setEcoleOrigine] = useState("");

  // Fichiers nouvellement choisis (peuvent rester vides si on ne change pas
  // un document déjà envoyé lors d'une modification).
  const [files, setFiles] = useState({});
  // Chemins déjà enregistrés en base, pour savoir ce qui est déjà envoyé.
  const [existingPaths, setExistingPaths] = useState({});

  // Charge l'inscription existante, s'il y en a une (cas d'une modification).
  useEffect(() => {
    async function load() {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/connexion");
        return;
      }

      const { data } = await supabase
        .from("inscriptions")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (data) {
        const isPasserelle = passerelle.includes(data.filiere);
        const isMaster = master.includes(data.filiere);
        setCycle(isPasserelle ? "Passerelle" : isMaster ? "Master" : "Licence");
        setFiliere(data.filiere || "");
        setNiveau(data.niveau || "");
        setVacation(data.vacation || "");
        setDateNaissance(data.date_naissance || "");
        setLieuNaissance(data.lieu_naissance || "");
        setSexe(data.sexe || "");
        setAdresse(data.adresse || "");
        setTelephone(data.telephone || "");
        setEcoleOrigine(data.ecole_origine || "");
        setStatut(data.statut);
        setExistingPaths({
          diplome: data.diplome_path,
          carte_identite: data.carte_identite_path,
          photo: data.photo_path,
          acte_naissance: data.acte_naissance_path,
        });
      }

      setLoading(false);
    }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filieresDisponibles = cycle === "Licence" ? licence : cycle === "Passerelle" ? passerelle : master;
  const niveauxDisponibles = niveauxParCycle[cycle];

  function handleCycleChange(newCycle) {
    setCycle(newCycle);
    setFiliere("");
    setNiveau("");
  }

  function handleFileChange(key, fileList) {
    const file = fileList[0];
    if (!file) return;

    if (!ACCEPTED_TYPES.includes(file.type)) {
      setError(`${file.name} : formats acceptés = PDF, JPG ou PNG.`);
      return;
    }
    if (file.size > MAX_FILE_SIZE) {
      setError(`${file.name} dépasse 5 Mo.`);
      return;
    }

    setError(null);
    setFiles((prev) => ({ ...prev, [key]: file }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    setSaving(true);

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/connexion");
        return;
      }

      // On exige chaque document au premier envoi, mais pas si l'étudiant a
      // déjà un fichier enregistré et ne le remplace pas cette fois-ci.
      for (const doc of DOCUMENTS) {
        if (!files[doc.key] && !existingPaths[doc.key]) {
          throw new Error(`Le document "${doc.label}" est obligatoire.`);
        }
      }

      // Upload des nouveaux fichiers uniquement.
      const paths = { ...existingPaths };
      for (const doc of DOCUMENTS) {
        const file = files[doc.key];
        if (!file) continue;

        const ext = file.name.split(".").pop();
        const path = `${user.id}/${doc.key}.${ext}`;

        const { error: uploadError } = await supabase.storage
          .from("documents")
          .upload(path, file, { upsert: true });

        if (uploadError) throw uploadError;
        paths[doc.key] = path;
      }

      const { error: upsertError } = await supabase.from("inscriptions").upsert(
        {
          user_id: user.id,
          filiere,
          niveau,
          vacation,
          date_naissance: dateNaissance || null,
          lieu_naissance: lieuNaissance,
          sexe,
          adresse,
          telephone,
          ecole_origine: ecoleOrigine,
          diplome_path: paths.diplome,
          carte_identite_path: paths.carte_identite,
          photo_path: paths.photo,
          acte_naissance_path: paths.acte_naissance,
          statut: "en_attente", // toute modification repasse en attente de vérification
        },
        { onConflict: "user_id" }
      );

      if (upsertError) throw upsertError;

      setSuccess(true);
      setStatut("en_attente");
    } catch (err) {
      setError(err.message || "Une erreur est survenue, réessaie.");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <section className="about" style={{ paddingTop: 140 }}>
        <div className="wrap">
          <p>Chargement…</p>
        </div>
      </section>
    );
  }

  return (
    <section className="about" style={{ paddingTop: 140, paddingBottom: 80 }}>
      <div className="wrap" style={{ maxWidth: 640 }}>
        <span className="eyebrow">Espace étudiant</span>
        <h2>Formulaire d'inscription</h2>

        {statut && (
          <p
            style={{
              display: "inline-block",
              fontSize: "0.9rem",
              fontWeight: 600,
              color: statutLabels[statut]?.color,
              background: "var(--bg-soft)",
              padding: "8px 16px",
              borderRadius: 50,
              marginBottom: 24,
            }}
          >
            Statut actuel : {statutLabels[statut]?.text}
          </p>
        )}

        {success && (
          <p className="form-note" style={{ marginBottom: 24 }}>
            Ta demande a bien été enregistrée. Tu recevras une réponse une fois ton dossier
            examiné.
          </p>
        )}

        <form onSubmit={handleSubmit} className="contact-form">
          <div className="contact-form-card">
            <h3 style={{ marginTop: 0 }}>Formation souhaitée</h3>
            <div className="form-row">
              <label>
                Cycle
                <select value={cycle} onChange={(e) => handleCycleChange(e.target.value)}>
                  <option value="Licence">Licence (Sections Organisées)</option>
                  <option value="Passerelle">Passerelle (Licence Spéciale 1,5 an)</option>
                  <option value="Master">Master</option>
                </select>
              </label>
              <label>
                Niveau
                <select value={niveau} onChange={(e) => setNiveau(e.target.value)} required>
                  <option value="" disabled>Choisir…</option>
                  {niveauxDisponibles.map((n) => (
                    <option key={n} value={n}>{n}</option>
                  ))}
                </select>
              </label>
            </div>
            <label>
              Filière
              <select value={filiere} onChange={(e) => setFiliere(e.target.value)} required>
                <option value="" disabled>Choisir…</option>
                {filieresDisponibles.map((f) => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
            </label>
            <label>
              Vacation (régime des cours)
              <select value={vacation} onChange={(e) => setVacation(e.target.value)} required>
                <option value="" disabled>Choisir…</option>
                <option value="Jour">Jour</option>
                <option value="Soir">Soir</option>
              </select>
            </label>
          </div>

          <div className="contact-form-card">
            <h3 style={{ marginTop: 0 }}>Informations personnelles</h3>
            <div className="form-row">
              <label>
                Date de naissance
                <input
                  type="date"
                  value={dateNaissance}
                  onChange={(e) => setDateNaissance(e.target.value)}
                  required
                />
              </label>
              <label>
                Lieu de naissance
                <input
                  type="text"
                  value={lieuNaissance}
                  onChange={(e) => setLieuNaissance(e.target.value)}
                  required
                />
              </label>
            </div>
            <div className="form-row">
              <label>
                Sexe
                <select value={sexe} onChange={(e) => setSexe(e.target.value)} required>
                  <option value="" disabled>Choisir…</option>
                  <option value="Masculin">Masculin</option>
                  <option value="Féminin">Féminin</option>
                </select>
              </label>
              <label>
                Téléphone
                <input
                  type="tel"
                  value={telephone}
                  onChange={(e) => setTelephone(e.target.value)}
                  required
                />
              </label>
            </div>
            <label>
              Adresse
              <input
                type="text"
                value={adresse}
                onChange={(e) => setAdresse(e.target.value)}
                required
              />
            </label>
            <label>
              École d'origine (dernier établissement fréquenté)
              <input
                type="text"
                value={ecoleOrigine}
                onChange={(e) => setEcoleOrigine(e.target.value)}
                required
              />
            </label>
          </div>

          <div className="contact-form-card">
            <h3 style={{ marginTop: 0 }}>Documents</h3>
            <p style={{ color: "var(--muted)", fontSize: "0.9rem", marginTop: -8 }}>
              Formats acceptés : PDF, JPG, PNG — 5 Mo maximum par fichier.
            </p>
            {DOCUMENTS.map((doc) => (
              <label key={doc.key} style={{ marginBottom: 18, display: "block" }}>
                {doc.label}
                {existingPaths[doc.key] && !files[doc.key] && (
                  <span style={{ color: "#1E7A4C", fontSize: "0.85rem", marginLeft: 8 }}>
                    ✓ déjà envoyé
                  </span>
                )}
                <input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={(e) => handleFileChange(doc.key, e.target.files)}
                />
              </label>
            ))}
          </div>

          {error && <p className="form-note" style={{ color: "#B4232C" }}>{error}</p>}

          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? "Envoi en cours…" : "Envoyer ma demande d'inscription"}
          </button>
        </form>
      </div>
    </section>
  );
}
