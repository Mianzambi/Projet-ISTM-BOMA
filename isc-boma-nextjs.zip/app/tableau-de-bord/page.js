import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import LogoutButton from "@/components/LogoutButton";
import { DOCUMENTS } from "@/lib/documents";
import { statutLabels } from "@/lib/statuts";

export default async function TableauDeBordPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/connexion");
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name")
    .eq("id", user.id)
    .maybeSingle();

  const fullName = profile?.full_name || user.user_metadata?.full_name || "Étudiant";

  const [{ data: inscription }, { data: paiements }, { data: coupon }] = await Promise.all([
    supabase.from("inscriptions").select("*").eq("user_id", user.id).maybeSingle(),
    supabase
      .from("paiements")
      .select("*")
      .eq("user_id", user.id)
      .order("date_paiement", { ascending: false }),
    supabase.from("coupons").select("*").eq("user_id", user.id).maybeSingle(),
  ]);

  let documentLinks = {};
  let horaires = [];
  let camarades = [];
  let montantFixe = null;

  if (inscription) {
    const entries = await Promise.all(
      DOCUMENTS.map(async (doc) => {
        const path = inscription[`${doc.key}_path`];
        if (!path) return [doc.key, null];
        const { data } = await supabase.storage.from("documents").createSignedUrl(path, 300);
        return [doc.key, data?.signedUrl || null];
      })
    );
    documentLinks = Object.fromEntries(entries);

    const { data: horairesData } = await supabase
      .from("horaires")
      .select("*")
      .eq("filiere", inscription.filiere)
      .eq("niveau", inscription.niveau)
      .order("jour", { ascending: true });
    horaires = horairesData || [];

    const { data: promotionData } = await supabase
      .from("promotion_publique")
      .select("*")
      .eq("filiere", inscription.filiere)
      .eq("niveau", inscription.niveau);
    camarades = promotionData || [];

    const { data: frais } = await supabase
      .from("frais_academiques")
      .select("*")
      .eq("niveau", inscription.niveau)
      .maybeSingle();
    montantFixe = frais || null;
  }

  let couponUrl = null;
  if (coupon) {
    const { data } = await supabase.storage.from("coupons").createSignedUrl(coupon.coupon_path, 300);
    couponUrl = data?.signedUrl || null;
  }

  const totalPaye = (paiements || []).reduce((sum, p) => sum + Number(p.montant), 0);
  const devise = montantFixe?.devise || paiements?.[0]?.devise || "FC";
  const montantFixeVal = montantFixe ? Number(montantFixe.montant) : null;
  const resteAPayer = montantFixeVal !== null ? Math.max(montantFixeVal - totalPaye, 0) : null;

  const statutStyles = {
    en_attente: "bg-amber-500/10 text-amber-400 border-amber-500/20",
    validee: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    rejetee: "bg-red-500/10 text-red-400 border-red-500/20",
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur px-6 py-4 flex justify-between items-center">
        <div>
          <h1 className="text-base font-bold text-white tracking-wide">ISC BOMA</h1>
          <p className="text-xs text-slate-400">Portail Étudiant</p>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-xs text-slate-300 hidden sm:inline">{user.email}</span>
          <LogoutButton />
        </div>
      </header>

      <main className="flex-1 max-w-5xl w-full mx-auto p-6 space-y-6">
        {/* Bannière de bienvenue */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h2 className="text-xl font-bold text-white">Bonjour, {fullName}</h2>
            <p className="text-xs text-slate-400 mt-1">{user.email}</p>
            {inscription && (
              <p className="text-xs text-slate-500 mt-0.5">
                Étudiant(e) de la promotion {inscription.niveau} — {inscription.filiere}
                {inscription.vacation ? ` (Vacation ${inscription.vacation})` : ""}
              </p>
            )}
          </div>
          {inscription && (
            <div className={`px-3 py-1.5 border rounded-full text-xs font-medium whitespace-nowrap ${statutStyles[inscription.statut]}`}>
              ● {statutLabels[inscription.statut]?.text}
            </div>
          )}
        </div>

        {/* Dossier d'inscription */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Mon dossier d&apos;inscription
          </h3>

          {inscription ? (
            <>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-slate-800">
                  <span className="text-slate-400">Filière</span>
                  <span className="text-white font-medium">{inscription.filiere}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Niveau</span>
                  <span className="text-white font-medium">{inscription.niveau}</span>
                </div>
              </div>

              <div className="pt-2">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Documents</h4>
                <div className="space-y-1.5">
                  {DOCUMENTS.map((doc) => (
                    <div key={doc.key} className="flex justify-between text-xs py-1 border-b border-slate-800 last:border-0">
                      <span className="text-slate-400">{doc.label}</span>
                      {documentLinks[doc.key] ? (
                        <a href={documentLinks[doc.key]} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline font-medium">
                          Voir
                        </a>
                      ) : (
                        <span className="text-slate-600">—</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <a href="/tableau-de-bord/inscription" className="inline-block mt-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg transition-colors">
                Modifier mon dossier
              </a>
            </>
          ) : (
            <>
              <p className="text-xs text-slate-400">Tu n&apos;as pas encore complété ta demande d&apos;inscription.</p>
              <a href="/tableau-de-bord/inscription" className="inline-block px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium rounded-lg transition-colors">
                Remplir mon dossier d&apos;inscription
              </a>
            </>
          )}
        </div>

        {/* Coupon / Résultat */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">Résultat</h3>
          {couponUrl ? (
            <a href={couponUrl} target="_blank" rel="noopener noreferrer" className="inline-block px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium rounded-lg transition-colors">
              Télécharger mon coupon (PDF)
            </a>
          ) : (
            <p className="text-xs text-slate-400">Aucun coupon n&apos;a encore été publié pour l&apos;instant.</p>
          )}
        </div>

        {/* Horaires */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">Horaires</h3>
          {horaires.length > 0 ? (
            <div className="space-y-1.5">
              {horaires.map((h) => (
                <div key={h.id} className="flex justify-between text-xs py-1 border-b border-slate-800 last:border-0">
                  <span className="text-slate-400">{h.jour} {h.heure_debut}–{h.heure_fin}</span>
                  <span className="text-white font-medium">{h.matiere} {h.salle ? `(${h.salle})` : ""}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-400">L&apos;horaire de ta promotion n&apos;a pas encore été publié.</p>
          )}
        </div>

        {/* Ma promotion */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Ma promotion ({camarades.length})
          </h3>
          {camarades.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {camarades.map((c, i) => (
                <div key={i} className="text-xs text-slate-300 bg-slate-800/50 rounded-lg px-3 py-2">
                  {c.full_name || "Étudiant(e)"}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-400">Aucun autre étudiant validé dans ta promotion pour l&apos;instant.</p>
          )}
        </div>

        {/* Finance */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">Finance</h3>
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs py-1 border-b border-slate-800">
              <span className="text-slate-400">Montant fixé</span>
              <span className="text-white font-medium">
                {montantFixeVal !== null ? `${montantFixeVal.toLocaleString("fr-FR")} ${devise}` : "—"}
              </span>
            </div>
            <div className="flex justify-between text-xs py-1 border-b border-slate-800">
              <span className="text-slate-400">Déjà payé</span>
              <span className="text-emerald-400 font-semibold">{totalPaye.toLocaleString("fr-FR")} {devise}</span>
            </div>
            <div className="flex justify-between text-xs py-1">
              <span className="text-slate-400">Reste à payer</span>
              <span className="text-amber-400 font-semibold">
                {resteAPayer !== null ? `${resteAPayer.toLocaleString("fr-FR")} ${devise}` : "—"}
              </span>
            </div>
          </div>

          {paiements && paiements.length > 0 && (
            <div className="pt-2">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Historique</h4>
              <div className="space-y-1.5">
                {paiements.map((p) => (
                  <div key={p.id} className="flex justify-between text-xs py-1 border-b border-slate-800 last:border-0">
                    <span className="text-slate-400">
                      {new Date(p.date_paiement).toLocaleDateString("fr-FR")} — {p.motif}
                    </span>
                    <span className="text-white font-medium">
                      {Number(p.montant).toLocaleString("fr-FR")} {p.devise}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
