import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import LogoutButton from "@/components/LogoutButton";

export default async function AdminHubPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/connexion");

  const { data: adminRow } = await supabase
    .from("admins")
    .select("user_id")
    .eq("user_id", user.id)
    .maybeSingle();

  if (!adminRow) redirect("/tableau-de-bord");

  return (
    <div style={{ background: "#fff", minHeight: "100vh" }}>
      <header className="site-header">
        <div className="header-inner">
          <div className="brand">
            <img src="/logo.jpg" alt="Logo ISTM" style={{ height: 32, width: "auto", borderRadius: 4, marginRight: 8 }} />
            Administration ISTM-BOMA
          </div>
          <div className="header-actions">
            <span style={{ fontSize: "0.85rem", color: "var(--muted)" }}>{user.email}</span>
            <LogoutButton />
          </div>
        </div>
      </header>

      <main className="wrap" style={{ paddingTop: 64, paddingBottom: 80 }}>
        <div className="admin-hub-box">
          <div className="admin-hub-title">
            BIENVENUE AU TABLEAU DE BORD ADMINISTRATION
            <br />
            DE L&apos;ISTM / BOMA
          </div>

          <div className="admin-hub-grid">
            <a href="/admin/vacation/Jour" className="admin-hub-btn blue">
              Vacation jour
            </a>
            <a href="/admin/vacation/Soir" className="admin-hub-btn navy">
              Vacation Soir
            </a>
            <a href="/admin/inscriptions" className="admin-hub-btn blue">
              Inscription en attente
            </a>
          </div>
          <div className="admin-hub-grid single">
            <a href="/admin/frais" className="admin-hub-btn blue">
              Frais académique
            </a>
          </div>
        </div>
      </main>
    </div>
  );
}
