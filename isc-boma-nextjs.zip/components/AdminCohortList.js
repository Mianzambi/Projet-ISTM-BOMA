"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AdminCohortList({ students }) {
  const [selectedId, setSelectedId] = useState(null);
  const router = useRouter();

  function handleGerer() {
    if (selectedId) router.push(`/admin/etudiant/${selectedId}`);
  }

  if (students.length === 0) {
    return <p style={{ color: "var(--muted)" }}>Aucun étudiant dans cette promotion pour l&apos;instant.</p>;
  }

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 24, alignItems: "start" }}>
      <ul className="admin-student-list">
        {students.map((s) => (
          <li
            key={s.user_id}
            className={selectedId === s.user_id ? "selected" : ""}
            onClick={() => setSelectedId(s.user_id)}
          >
            {s.full_name || "Nom inconnu"}
          </li>
        ))}
      </ul>
      <button
        onClick={handleGerer}
        disabled={!selectedId}
        className="btn btn-primary"
        style={{ whiteSpace: "nowrap" }}
      >
        Gérer
      </button>
    </div>
  );
}
