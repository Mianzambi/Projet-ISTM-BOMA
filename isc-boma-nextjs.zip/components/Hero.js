export default function Hero() {
  return (
    <>
      <section className="hero" id="accueil">
        <div className="hero-inner">
          <span className="pill-badge">
            <span className="dot"></span> Inscriptions 2026–2027 en cours
          </span>
          <h1>Institut Supérieur des Techniques Médicales de Boma</h1>
          <p className="hero-sub">
            Formations d'excellence en sciences infirmières, obstétrique, biologie médicale et gestion des services de santé. <em>"Scientia Splendet et Conscientia"</em>.
          </p>
          <div className="hero-actions">
            <a href="/inscription" className="btn btn-primary">S’inscrire maintenant</a>
            <a href="#filieres" className="btn btn-outline-light">Nos Filières</a>
          </div>
        </div>
        <div className="stat-strip">
          <div className="stat">
            <span className="stat-num">4</span>
            <span className="stat-label">Sections Organisées</span>
          </div>
          <div className="stat">
            <span className="stat-num">1.5 an</span>
            <span className="stat-label">Programme Passerelle</span>
          </div>
          <div className="stat">
            <span className="stat-num">Jour & Soir</span>
            <span className="stat-label">Vacations au choix</span>
          </div>
        </div>
      </section>
      <div className="hero-spacer"></div>
    </>
  );
}
