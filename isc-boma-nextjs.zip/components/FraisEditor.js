"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function FraisEditor({ initialFrais }) {
  const [frais, setFrais] = useState(initialFrais);
  const [saving, setSaving] = useState(null);
  const [savedNiveau, setSavedNiveau] = useState(null);
  const [message, setMessage] = useState({ type: "", text: "" });

  function handleChange(niveau, montant) {
    setFrais((prev) => prev.map((f) => (f.niveau === niveau ? { ...f, montant } : f)));
  }

  async function handleSave(niveau) {
    const item = frais.find((f) => f.niveau === niveau);
    setSaving(niveau);
    setSavedNiveau(null);
    const supabase = createClient();

    const { error } = await supabase
      .from("frais_academiques")
      .update({ montant: Number(item.montant) })
      .eq("niveau", niveau);

    setSaving(null);
    if (error) {
      setMessage({ type: "error", text: "Erreur : " + error.message });
      return;
    }
    setMessage({ type: "success", text: "Frais enregistrés avec succès." });
    setSavedNiveau(niveau);
    setTimeout(() => setSavedNiveau(null), 2000);
  }

  return (
    <div>
      {message.text && (
        <div
          style={{
            marginBottom: 14,
            padding: "10px 12px",
            borderRadius: 8,
            fontSize: "0.85rem",
            color: message.type === "error" ? "#b42318" : "#065f46",
            background:
              message.type === "error" ? "rgba(180,35,24,0.08)" : "rgba(6,95,70,0.08)",
            border:
              message.type === "error"
                ? "1px solid rgba(180,35,24,0.2)"
                : "1px solid rgba(6,95,70,0.2)",
          }}
        >
          {message.text}
        </div>
      )}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
      {frais.map((f) => (
        <div
          key={f.niveau}
          style={{
            background: f.niveau.startsWith("L") ? "var(--blue)" : "var(--navy)",
            borderRadius: 10,
            padding: "16px 18px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 10,
          }}
        >
          <span style={{ color: "#fff", fontWeight: 700 }}>{f.niveau}</span>
          <input
            type="number"
            value={f.montant}
            onChange={(e) => handleChange(f.niveau, e.target.value)}
            style={{
              width: 110,
              padding: "6px 8px",
              borderRadius: 6,
              border: "none",
              textAlign: "right",
              fontWeight: 600,
            }}
          />
          <span style={{ color: "#fff", fontSize: "0.8rem" }}>{f.devise}</span>
          <button
            onClick={() => handleSave(f.niveau)}
            disabled={saving === f.niveau}
            style={{
              background: "rgba(255,255,255,0.2)",
              color: "#fff",
              border: "none",
              borderRadius: 6,
              padding: "6px 10px",
              fontSize: "0.75rem",
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            {saving === f.niveau ? "…" : savedNiveau === f.niveau ? "✓" : "Enregistrer"}
          </button>
        </div>
      ))}
      </div>
    </div>
  );
}
