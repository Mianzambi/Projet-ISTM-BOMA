"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { statutLabels } from "@/lib/statuts";

export default function AdminInscriptionsTable({ initialInscriptions, documents }) {
  const [inscriptions, setInscriptions] = useState(initialInscriptions);
  const [updatingId, setUpdatingId] = useState(null);
  const [statusMessage, setStatusMessage] = useState({ type: "", text: "" });

  async function updateStatut(id, nouveauStatut) {
    setUpdatingId(id);
    const supabase = createClient();

    const { error } = await supabase
      .from("inscriptions")
      .update({ statut: nouveauStatut })
      .eq("id", id);

    setUpdatingId(null);

    if (error) {
      setStatusMessage({
        type: "error",
        text: "Erreur lors de la mise à jour : " + error.message,
      });
      return;
    }

    setStatusMessage({
      type: "success",
      text: "Statut mis à jour avec succès.",
    });

    setInscriptions((prev) =>
      prev.map((item) => (item.id === id ? { ...item, statut: nouveauStatut } : item))
    );
  }

  if (inscriptions.length === 0) {
    return (
      <div className="admin-table-wrap" style={{ padding: 48, textAlign: "center", color: "var(--muted)" }}>
        Aucune inscription enregistrée pour le moment.
      </div>
    );
  }

  return (
    <div className="admin-table-wrap">
      {statusMessage.text && (
        <div
          style={{
            marginBottom: 16,
            padding: "10px 12px",
            borderRadius: 8,
            fontSize: "0.85rem",
            color: statusMessage.type === "error" ? "#b42318" : "#065f46",
            background:
              statusMessage.type === "error" ? "rgba(180,35,24,0.08)" : "rgba(6,95,70,0.08)",
            border:
              statusMessage.type === "error"
                ? "1px solid rgba(180,35,24,0.2)"
                : "1px solid rgba(6,95,70,0.2)",
          }}
        >
          {statusMessage.text}
        </div>
      )}
      <div style={{ overflowX: "auto" }}>
        <table className="admin-table">
          <thead>
            <tr>
              <th>Étudiant</th>
              <th>Filière / Niveau</th>
              <th>Infos personnelles</th>
              <th>Documents</th>
              <th>Statut</th>
              <th style={{ textAlign: "right" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {inscriptions.map((item) => (
              <tr key={item.id}>
                <td>
                  <div style={{ fontWeight: 600, color: "var(--ink)" }}>
                    {item.profile?.full_name || "Nom inconnu"}
                  </div>
                  <div style={{ fontSize: "0.8rem", color: "var(--muted)" }}>{item.profile?.email}</div>
                  <div style={{ fontSize: "0.8rem", color: "var(--muted)" }}>{item.telephone}</div>
                </td>
                <td>
                  <div style={{ fontWeight: 600, color: "var(--ink)" }}>{item.filiere}</div>
                  <div style={{ fontSize: "0.8rem", color: "var(--muted)" }}>Niveau : {item.niveau}</div>
                </td>
                <td style={{ fontSize: "0.8rem", color: "var(--body-text)" }}>
                  <div>Sexe : {item.sexe}</div>
                  <div>Né(e) le {item.date_naissance} à {item.lieu_naissance}</div>
                  <div>École : {item.ecole_origine}</div>
                </td>
                <td>
                  {documents.map((doc) =>
                    item.documentLinks[doc.key] ? (
                      <div key={doc.key}>
                        <a
                          href={item.documentLinks[doc.key]}
                          target="_blank"
                          rel="noreferrer"
                          className="admin-doc-link"
                        >
                          {doc.label}
                        </a>
                      </div>
                    ) : (
                      <div key={doc.key} className="admin-doc-missing">
                        {doc.label} — manquant
                      </div>
                    )
                  )}
                </td>
                <td>
                  <span
                    className="admin-badge"
                    style={{
                      color: statutLabels[item.statut]?.color,
                      background: "var(--bg-soft)",
                      border: `1px solid ${statutLabels[item.statut]?.color}`,
                    }}
                  >
                    {statutLabels[item.statut]?.text || item.statut}
                  </span>
                </td>
                <td>
                  <div className="admin-actions">
                    <a href={`/admin/etudiant/${item.user_id}`} className="admin-btn admin-btn-manage" style={{ textDecoration: "none", display: "inline-block" }}>
                      Gérer
                    </a>
                    <button
                      onClick={() => updateStatut(item.id, "validee")}
                      disabled={updatingId === item.id}
                      className="admin-btn admin-btn-validate"
                    >
                      Valider
                    </button>
                    <button
                      onClick={() => updateStatut(item.id, "rejetee")}
                      disabled={updatingId === item.id}
                      className="admin-btn admin-btn-reject"
                    >
                      Rejeter
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
