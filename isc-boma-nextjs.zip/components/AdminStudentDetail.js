"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function AdminStudentDetail({
  userId,
  inscription,
  documentLinks,
  documents,
  initialPaiements,
  montantFixe,
  initialCoupon,
  initialCouponUrl,
}) {
  const [paiements, setPaiements] = useState(initialPaiements);
  const [coupon, setCoupon] = useState(initialCoupon);
  const [couponUrl, setCouponUrl] = useState(initialCouponUrl);
  const [couponFile, setCouponFile] = useState(null);
  const [dragOver, setDragOver] = useState(false);

  const [nouveauMontant, setNouveauMontant] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const totalPaye = paiements.reduce((sum, p) => sum + Number(p.montant), 0);
  const montantFixeVal = montantFixe ? Number(montantFixe.montant) : null;
  const resteAPayer = montantFixeVal !== null ? Math.max(montantFixeVal - totalPaye, 0) : null;
  const devise = montantFixe?.devise || "FC";

  function handleFileSelect(fileList) {
    const file = fileList[0];
    if (!file) return;
    if (file.type !== "application/pdf") {
      setError("Le coupon doit être un fichier PDF.");
      return;
    }
    setError(null);
    setCouponFile(file);
  }

  async function ajouterCoupon() {
    if (!couponFile) return;
    setSaving(true);
    setError(null);
    const supabase = createClient();

    const path = `${userId}/coupon.pdf`;
    const { error: uploadError } = await supabase.storage
      .from("coupons")
      .upload(path, couponFile, { upsert: true });

    if (uploadError) {
      setSaving(false);
      setError(uploadError.message);
      return;
    }

    const { data, error: dbError } = await supabase
      .from("coupons")
      .upsert({ user_id: userId, coupon_path: path, uploaded_at: new Date().toISOString() }, { onConflict: "user_id" })
      .select()
      .single();

    setSaving(false);
    if (dbError) {
      setError(dbError.message);
      return;
    }

    setCoupon(data);
    const { data: signed } = await supabase.storage.from("coupons").createSignedUrl(path, 300);
    setCouponUrl(signed?.signedUrl || null);
    setCouponFile(null);
  }

  async function confirmerPaiement() {
    if (!nouveauMontant) return;
    setSaving(true);
    setError(null);
    const supabase = createClient();

    const { data, error: insertError } = await supabase
      .from("paiements")
      .insert({
        user_id: userId,
        montant: Number(nouveauMontant),
        devise,
        motif: "Frais académique",
        mode_paiement: "Espèces au guichet",
        date_paiement: new Date().toISOString().slice(0, 10),
      })
      .select()
      .single();

    setSaving(false);
    if (insertError) {
      setError(insertError.message);
      return;
    }
    setPaiements((prev) => [data, ...prev]);
    setNouveauMontant("");
  }

  return (
    <div style={{ display: "grid", gap: 20 }}>
      {error && (
        <div className="form-note" style={{ color: "#B4232C" }}>
          {error}
        </div>
      )}

      {/* Dossier d'inscription */}
      <div className="contact-form-card">
        <h3 style={{ marginTop: 0 }}>Dossier d&apos;inscription</h3>
        {inscription ? (
          <>
            <p>{inscription.niveau} — {inscription.filiere} — Vacation {inscription.vacation || "—"}</p>
            {documents.map((doc) => (
              <div key={doc.key} style={{ display: "flex", justifyContent: "space-between", fontSize: "0.85rem", padding: "8px 0", borderTop: "1px solid var(--border)" }}>
                <span style={{ color: "var(--muted)" }}>{doc.label}</span>
                {documentLinks[doc.key] ? (
                  <a href={documentLinks[doc.key]} target="_blank" rel="noreferrer" className="admin-doc-link">Voir</a>
                ) : (
                  <span className="admin-doc-missing">manquant</span>
                )}
              </div>
            ))}
          </>
        ) : (
          <p style={{ color: "var(--muted)" }}>Cet étudiant n&apos;a pas encore complété de demande d&apos;inscription.</p>
        )}
      </div>

      {/* RESULTAT + FINANCE côte à côte */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {/* RESULTAT */}
        <div className="contact-form-card">
          <h3 style={{ marginTop: 0 }}>RÉSULTAT</h3>

          {coupon && !couponFile && (
            <p style={{ fontSize: "0.85rem", marginBottom: 12 }}>
              Coupon actuel :{" "}
              <a href={couponUrl} target="_blank" rel="noreferrer" className="admin-doc-link">
                voir le PDF
              </a>
            </p>
          )}

          <div
            className={`dropzone ${dragOver ? "dragover" : ""}`}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              handleFileSelect(e.dataTransfer.files);
            }}
            onClick={() => document.getElementById(`coupon-input-${userId}`).click()}
          >
            {couponFile ? (
              <span>{couponFile.name} — prêt à envoyer</span>
            ) : (
              <span>Glissez-déposez le coupon PDF ici, ou cliquez pour l&apos;importer</span>
            )}
            <input
              id={`coupon-input-${userId}`}
              type="file"
              accept="application/pdf"
              style={{ display: "none" }}
              onChange={(e) => handleFileSelect(e.target.files)}
            />
          </div>

          <button
            onClick={ajouterCoupon}
            disabled={!couponFile || saving}
            className="btn btn-primary"
            style={{ marginTop: 14, width: "100%" }}
          >
            Ajouter
          </button>
        </div>

        {/* FINANCE */}
        <div className="contact-form-card">
          <h3 style={{ marginTop: 0 }}>FINANCE</h3>

          <div style={{ fontSize: "0.9rem", display: "grid", gap: 8, marginBottom: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: "var(--muted)" }}>Montant fixé</span>
              <span style={{ fontWeight: 700 }}>
                {montantFixeVal !== null ? `${montantFixeVal.toLocaleString("fr-FR")} ${devise}` : "—"}
              </span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: "var(--muted)" }}>Déjà payé</span>
              <span style={{ fontWeight: 700, color: "#1E7A4C" }}>
                {totalPaye.toLocaleString("fr-FR")} {devise}
              </span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <span style={{ color: "var(--muted)" }}>Reste à payer</span>
              <span style={{ fontWeight: 700, color: "#B8860B" }}>
                {resteAPayer !== null ? `${resteAPayer.toLocaleString("fr-FR")} ${devise}` : "—"}
              </span>
            </div>
          </div>

          <p style={{ fontSize: "0.78rem", color: "var(--muted)", marginBottom: 8 }}>
            Le montant fixé se règle une fois pour tous les étudiants du niveau, dans
            « Frais académique ». Ici, ajoute uniquement un nouveau paiement reçu.
          </p>

          <div style={{ display: "flex", gap: 8 }}>
            <input
              type="number"
              placeholder={`Montant reçu (${devise})`}
              value={nouveauMontant}
              onChange={(e) => setNouveauMontant(e.target.value)}
              className="admin-input"
            />
            <button onClick={confirmerPaiement} disabled={!nouveauMontant || saving} className="btn btn-primary">
              Confirmé
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
