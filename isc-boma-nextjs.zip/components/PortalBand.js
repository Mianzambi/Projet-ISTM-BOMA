export default function PortalBand() {
  return (
    <div className="wrap">
      <div className="portal-band" id="espace">
        <div className="portal-inner">
          <div>
            <h2>Votre espace personnel</h2>
            <p>
              Connecte-toi pour accéder à ton espace étudiant. Le suivi de dossier
              d’inscription et la consultation des résultats arrivent dans une prochaine
              étape.
            </p>
            <div className="portal-features">
              <div className="portal-feature">
                <span className="check">✓</span> Connexion sécurisée, 24h/24
              </div>
              <div className="portal-feature">
                <span className="check">✓</span> Ton profil, accessible en un clic
              </div>
              <div className="portal-feature">
                <span className="check">✓</span> Suivi de dossier et résultats (bientôt)
              </div>
            </div>
          </div>
          <div style={{ textAlign: "center", display: "flex", flexDirection: "column", gap: 12 }}>
            <a href="/inscription" className="btn btn-primary">Créer mon compte</a>
            <a href="/connexion" className="btn btn-outline-light">Se connecter</a>
          </div>
        </div>
      </div>
    </div>
  );
}

