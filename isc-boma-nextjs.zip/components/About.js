export default function About() {
  return (
    <section className="about" id="apropos">
      <div className="about-inner">
        <div className="about-visual" aria-hidden="true" style={{ background: "linear-gradient(135deg, #0F172A, #0369A1)", padding: "40px", borderRadius: 24, boxShadow: "var(--shadow-lg)" }}>
          <div style={{ textAlign: "center", color: "#fff" }}>
            <div style={{ width: 100, height: 100, margin: "0 auto 24px", background: "rgba(255,255,255,0.12)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(8px)", border: "1px solid rgba(255,255,255,0.2)" }}>
              <svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="#38BDF8" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" style={{ margin: "auto" }}>
                <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
                <path d="M12 5v14" />
                <path d="M5 12h14" />
              </svg>
            </div>
            <h3 style={{ color: "#fff", fontSize: "1.35rem", marginBottom: 12 }}>Excellence & Éthique</h3>
            <p style={{ color: "rgba(255,255,255,0.8)", fontSize: "0.95rem", lineHeight: 1.6 }}>
              Formation de santé de référence à Boma.
            </p>
            <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 24, flexWrap: "wrap" }}>
              <span className="tag" style={{ background: "rgba(255,255,255,0.15)", color: "#fff", borderColor: "rgba(255,255,255,0.25)" }}>
                🩺 Soins
              </span>
              <span className="tag" style={{ background: "rgba(255,255,255,0.15)", color: "#fff", borderColor: "rgba(255,255,255,0.25)" }}>
                🧪 Biologie
              </span>
              <span className="tag" style={{ background: "rgba(255,255,255,0.15)", color: "#fff", borderColor: "rgba(255,255,255,0.25)" }}>
                👶 Obstétrique
              </span>
            </div>
          </div>
        </div>
        <div className="about-content">
          <span className="eyebrow">À propos de l'ISTM-BOMA</span>
          <h2>Former les professionnels de santé de demain</h2>
          <p>
            L’<strong>Institut Supérieur des Techniques Médicales de Boma (ISTM-BOMA)</strong> est un établissement d'enseignement supérieur du Ministère de l'Enseignement Supérieur et Universitaire en République Démocratique du Congo.
          </p>
          <p>
            Situé à Boma, dans le Kongo Central, notre institut prépare les étudiants à devenir des praticiens et cadres d'excellence dans le secteur de la santé, alliant compétence scientifique et conscience professionnelle (<em>Scientia Splendet et Conscientia</em>).
          </p>
          <p>
            Nous proposons des parcours de formation adaptés (vacations Jour et Soir), ainsi qu'une année de Passerelle (Licence Spéciale de 1 an et 6 mois) pour le perfectionnement des compétences biomédicales et infirmières.
          </p>
        </div>
      </div>
    </section>
  );
}
