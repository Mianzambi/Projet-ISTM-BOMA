"use client";

import { useState } from "react";

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="site-header">
      <div className="header-inner">
        <a href="#accueil" className="brand">
          <img
            src="/logo.jpg"
            alt="Logo ISTM BOMA"
            style={{ height: 42, width: "auto", borderRadius: 6, marginRight: 8 }}
          />
          ISTM / BOMA
        </a>

        <nav className="main-nav">
          <a href="#accueil">Accueil</a>
          <a href="#apropos">À propos</a>
          <a href="#filieres">Filières</a>
          <a href="#contact">Contact</a>
        </nav>

        <div className="header-actions">
          <a href="/connexion" className="btn btn-outline btn-sm">
            Connexion
          </a>
          <button
            className="nav-toggle"
            aria-label="Ouvrir le menu"
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </div>

      {open && (
        <nav
          className="wrap"
          style={{ display: "flex", flexDirection: "column", gap: 16, paddingBottom: 20 }}
        >
          <a href="#accueil" onClick={() => setOpen(false)}>Accueil</a>
          <a href="#apropos" onClick={() => setOpen(false)}>À propos</a>
          <a href="#filieres" onClick={() => setOpen(false)}>Filières</a>
          <a href="#contact" onClick={() => setOpen(false)}>Contact</a>
          <a
            href="/connexion"
            className="btn btn-outline btn-sm"
            style={{ textAlign: "center" }}
            onClick={() => setOpen(false)}
          >
            Connexion
          </a>
        </nav>
      )}
    </header>
  );
}
